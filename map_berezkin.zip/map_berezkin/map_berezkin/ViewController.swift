//
//  ViewController.swift
//  map_berezkin
//
//  Created by Берёзкин on 28.03.2022.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    
    //переменная лоя создания маршрута
    var itemMapFirst: MKMapItem!
    var itemMapSecond: MKMapItem!
    
    let manager: CLLocationManager = {
        
        let locationManager = CLLocationManager()
        
        locationManager.activityType = .fitness //точно определяет местоположение
        locationManager.desiredAccuracy = kCLLocationAccuracyBest //определяет точность
        locationManager.distanceFilter = 1 //фильтр дистанции
        locationManager.showsBackgroundLocationIndicator = true //отобразить индикатор на карте
        locationManager.pausesLocationUpdatesAutomatically = true //отоброжение обновления
        
        return locationManager
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.delegate = self
        manager.delegate = self
        
        authorization() //вызываем функцию авторизации
        pinPosition() //вызывыаем функцию добавления точек
    }
    
    //функция добавления точек на карте
    func pinPosition(){
        
        //Массивы с координатами
        let arrayLet = [55.45, 37.36]
        let arrayLon = [129.73, 30.52]
        
        //Добваление на карту
        for number in 0..<arrayLet.count {
            
            let point = MKPointAnnotation()
            point.title = "My point"
            point.coordinate = CLLocationCoordinate2D(latitude: arrayLet[number], longitude: arrayLon[number])
            mapView.addAnnotation(point)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateHeading locations: [CLLocation]) {
    
        //отображение координат с помошью цикла
        for location in locations {
            
            print(location.coordinate.latitude)
            print(location.coordinate.longitude)
            itemMapFirst = MKMapItem(placemark: MKPlacemark(coordinate: location.coordinate))
        }
    }
    
    //функция авторизации
    func authorization(){
        
        //Проверка на разрешение испольтзования местоположения
        if CLLocationManager.authorizationStatus() == .authorizedAlways || CLLocationManager.authorizationStatus() == .authorizedWhenInUse {
            
            mapView.showsUserLocation = true //ОТобразить на карте текущее местоположение пользователя
            
        } else {
            
            manager.requestWhenInUseAuthorization() //Запрос на использование местоположение пользователя
            
        }
    }

    func calculayeRoute(){
        
        let request = MKDirections.Request() //Запрос на построение линии
        
        request.source = itemMapFirst //начальная точка
        request.destination = itemMapSecond //конечная точка
        request.requestsAlternateRoutes = true
        request.transportType = .walking //автомобили, дороги, все
        
        let direction = MKDirections(request: request)
        
        direction.calculate {(response, error) in
            
            guard let directionResponse = response else {return} //проверка
            
            let route = directionResponse.routes[0] //количество маршрутов
            
            self.mapView.addOverlay(route.polyline, level: .aboveRoads) //добавление линии на карте
            
        }
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        
        let render = MKPolygonRenderer(overlay: overlay)
        render.lineWidth = 5
        render.strokeColor = .red
        return render
    }

}

